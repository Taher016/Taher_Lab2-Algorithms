package com.greatlearning.paymoney;

import java.util.Scanner;

public class Driver {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of Transactions i.e., Number of days you want to consider");
		int size = sc.nextInt();
		int[] transactions = new int[size];
		for (int i = 0; i < size; i++) {
			System.out.println("Enter the no. of transactions in a day: " + (i+1));
			transactions[i] = sc.nextInt();
		}
		
		System.out.println("Enter the target amount which you want to track at a particular transaction");
		int target = sc.nextInt();
		PayMoney pm = new PayMoney();
		int numberofDays = pm.numberofDays(transactions, target);
		
		if (numberofDays == -1)
			System.out.println("The Target " + target + " is not achieved");
		else {
			System.out.println("The Target " + target + " achieved in " + numberofDays + " transactions");
		}
		//displayTransactions(transactions);
		sc.close();
	}
	
	public static void displayTransactions(int[] transactions) {
		for (int transaction : transactions) {
			System.out.print(transaction + " ");
		}
		System.out.println();
	}

}

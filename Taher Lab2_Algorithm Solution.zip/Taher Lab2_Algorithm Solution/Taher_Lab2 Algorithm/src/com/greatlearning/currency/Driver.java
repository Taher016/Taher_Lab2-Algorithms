package com.greatlearning.currency;

import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Currency Denominations");
		int numberofDenominations = sc.nextInt();
		int[] denominations = new int[numberofDenominations];
		System.out.println("Enter the Currency Denominations");
		for (int i = 0; i < numberofDenominations; i++) {
			denominations[i] = sc.nextInt();
		}
		System.out.println("Enter the amount which you want to pay");
		int amount = sc.nextInt();
		for (int i : denominations) {
			System.out.print(i + " ");
		}
		System.out.println();
		Currency currency = new Currency(denominations, numberofDenominations);
		MergeSort.sort(currency.denominations, 0, numberofDenominations - 1);
		for (int i = 0; i < numberofDenominations; i++) {
			System.out.print(currency.denominations[i] + " ");
		}
		System.out.println();
	}

}

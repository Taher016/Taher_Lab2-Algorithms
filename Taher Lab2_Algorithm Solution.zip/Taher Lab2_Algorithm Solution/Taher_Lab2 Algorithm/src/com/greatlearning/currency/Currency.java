package com.greatlearning.currency;

public class Currency {
	int[] denominations;
	int size;
	
	public Currency(int[] denominations, int size) {
		super();
		this.denominations = denominations;
		this.size = size;
	}

}
